def test(x):
    print(x)